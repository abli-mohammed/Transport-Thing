-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 11, 2020 at 05:40 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `transport_thing`
--

-- --------------------------------------------------------

--
-- Table structure for table `proposition_users`
--

CREATE TABLE IF NOT EXISTS `proposition_users` (
  `id_proposition` int(11) NOT NULL AUTO_INCREMENT,
  `id_request` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `is_free` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id_proposition`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `proposition_users`
--

INSERT INTO `proposition_users` (`id_proposition`, `id_request`, `id_user`, `is_free`) VALUES
(40, 14, 65, '200'),
(45, 19, 49, '2000');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE IF NOT EXISTS `request` (
  `id_request` int(11) NOT NULL AUTO_INCREMENT,
  `destination` varchar(50) NOT NULL,
  `arrival` varchar(50) NOT NULL,
  `id_type` int(11) NOT NULL,
  `date` varchar(20) NOT NULL,
  `status` int(11) NOT NULL,
  `is_emergency` int(11) NOT NULL,
  `is_free` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY (`id_request`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`id_request`, `destination`, `arrival`, `id_type`, `date`, `status`, `is_emergency`, `is_free`, `id_user`) VALUES
(4, 'msila', 'setif', 1, '2020/05/14', 0, 1, 1, 49),
(5, 'oran', 'alge', 1, '2020/05/14', 0, 1, 0, 49),
(6, 'mdia', 'ouladdradj', 3, '2020/05/05', 0, 0, 0, 49),
(8, 'msila', 'mtrfa', 2, '2020/05/11', 0, 1, 0, 49),
(13, 'msila', 'anaba', 2, '2020/05/12', 0, 1, 1, 49),
(14, 'oran', 'msila', 3, '2020/05/17', 0, 1, 0, 49),
(15, 'alge', 'bordj', 1, '2020/05/17', 0, 0, 0, 65),
(16, 'msila', 'bdjaia', 2, '2020/05/17', 0, 0, 0, 65),
(17, 'msila', 'bachar', 4, '2020/05/17', 0, 1, 0, 65),
(19, 'setif', 'alge', 2, '2020/05/17', 0, 0, 1, 50),
(20, 'setif', 'oran', 1, '2020/05/17', 0, 0, 0, 50),
(21, 'msila', 'ouladdradj', 2, '2020/05/21', 0, 1, 0, 49),
(22, 'msila', 'alge', 1, '2020/06/09', 0, 1, 0, 49),
(26, 'msila', 'ourgla', 2, '2020-06-18', 0, 0, 0, 62);

-- --------------------------------------------------------

--
-- Table structure for table `type_thing`
--

CREATE TABLE IF NOT EXISTS `type_thing` (
  `id_type` int(11) NOT NULL AUTO_INCREMENT,
  `type_thing` varchar(20) NOT NULL,
  PRIMARY KEY (`id_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `type_thing`
--

INSERT INTO `type_thing` (`id_type`, `type_thing`) VALUES
(1, 'Document'),
(2, 'Goods'),
(3, 'Person'),
(4, 'Other');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(50) CHARACTER SET utf8 NOT NULL,
  `firstname` varchar(20) CHARACTER SET utf8 NOT NULL,
  `lastname` varchar(20) CHARACTER SET utf8 NOT NULL,
  `birthdate` varchar(15) CHARACTER SET utf8 NOT NULL,
  `adress` varchar(30) CHARACTER SET utf8 NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8 NOT NULL,
  `status` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `type` int(11) NOT NULL,
  `username` varchar(30) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=83 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `password`, `firstname`, `lastname`, `birthdate`, `adress`, `phone`, `status`, `email`, `type`, `username`) VALUES
(49, 'ammar1995', 'ammar', 'abli', '1995-04-03', 'alger', '0665612970', 1, 'ammarabli16@gmail.com', 2, 'ammar'),
(50, '111111', 'achraf', 'hamrit', '1996-04-05', 'ouladdradj', '0656241524', 1, 'achraf96@gmail.com', 2, 'achraf'),
(62, '11', 'billal', 'lounas', '1987/02/02', 'msila', '0665624152', 1, 'billallounas@gmail.com', 1, 'admin'),
(65, '111111', 'rami', 'brahimi', '1996-01-02', 'msila', '0657451236', 1, 'ammarabli8@gmail.com', 2, 'rami'),
(66, '22', '', '', '', '', '', 2, 'amin@gmail.com', 2, 'amin'),
(78, '111111', 'mohammed', 'abli', '1855-05-02', 'alger', '0665653655', 1, 'abli.mohammedelamin@gmail.com', 2, 'mohammed'),
(82, '111111', 'rami', 'brahimi', '1996-02-01', 'msila', '0665612978', 1, 'ramibrarami@gmail.com', 2, 'rami25');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
