-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2020 at 05:22 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `transport_thing`
--

-- --------------------------------------------------------

--
-- Table structure for table `proposition_users`
--

CREATE TABLE IF NOT EXISTS `proposition_users` (
  `id_proposition` int(11) NOT NULL AUTO_INCREMENT,
  `id_request` int(11) NOT NULL,
  `id_user_demander` int(11) NOT NULL,
  `is_free` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id_proposition`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `proposition_users`
--

INSERT INTO `proposition_users` (`id_proposition`, `id_request`, `id_user_demander`, `is_free`) VALUES
(2, 7, 55, '5000'),
(4, 8, 55, '4500');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE IF NOT EXISTS `request` (
  `id_request` int(11) NOT NULL AUTO_INCREMENT,
  `destination` varchar(50) NOT NULL,
  `arrival` varchar(50) NOT NULL,
  `id_type` int(11) NOT NULL,
  `date` varchar(20) NOT NULL,
  `status` int(11) NOT NULL,
  `is_emergency` int(11) NOT NULL,
  `is_free` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY (`id_request`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`id_request`, `destination`, `arrival`, `id_type`, `date`, `status`, `is_emergency`, `is_free`, `id_user`) VALUES
(4, 'msila', 'setif', 2, '2020/04/08', 0, 0, 1, 49),
(5, 'oran', 'alge', 1, '2020/04/08', 0, 1, 0, 49),
(6, 'mdia', 'ouladdradj', 3, '2020/05/05', 0, 0, 0, 49),
(7, 'bousaada', 'barhom', 4, '2020/05/05', 0, 1, 0, 49),
(8, 'msila', 'mtrfa', 2, '2020/05/11', 0, 1, 0, 49),
(9, 'djalfa', 'biskra', 4, '2020/05/11', 0, 0, 1, 55);

-- --------------------------------------------------------

--
-- Table structure for table `type_thing`
--

CREATE TABLE IF NOT EXISTS `type_thing` (
  `id_type` int(11) NOT NULL AUTO_INCREMENT,
  `type_thing` varchar(20) NOT NULL,
  PRIMARY KEY (`id_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `type_thing`
--

INSERT INTO `type_thing` (`id_type`, `type_thing`) VALUES
(1, 'Document'),
(2, 'Goods'),
(3, 'Person'),
(4, 'Other');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) CHARACTER SET utf8 NOT NULL,
  `password` varchar(50) CHARACTER SET utf8 NOT NULL,
  `firstname` varchar(20) CHARACTER SET utf8 NOT NULL,
  `lastname` varchar(20) CHARACTER SET utf8 NOT NULL,
  `birthdate` varchar(15) CHARACTER SET utf8 NOT NULL,
  `adress` varchar(30) CHARACTER SET utf8 NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8 NOT NULL,
  `status` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `username_2` (`username`),
  UNIQUE KEY `username_3` (`username`),
  UNIQUE KEY `username_4` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=60 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `firstname`, `lastname`, `birthdate`, `adress`, `phone`, `status`, `email`, `type`) VALUES
(49, 'ammar', '11', 'ammar', 'abli', '1995-04-03', 'alger', '0665612970', 1, 'ammarabli16@gmail.com', 2),
(50, 'mohammed', '11', 'mohammed', 'abli', '1985-12-05', 'msila', '0667587865', 1, 'abli.mohammedemamin@gmail.com', 2),
(55, 'rami', '11', 'rami', 'brahimi', '1996-12-04', 'msila', '0557451236', 1, 'ammarabli8@gmail.com', 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
