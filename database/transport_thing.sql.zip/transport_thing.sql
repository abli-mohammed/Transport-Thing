-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2020 at 01:33 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `transport_thing`
--

-- --------------------------------------------------------

--
-- Table structure for table `proposition_users`
--

CREATE TABLE IF NOT EXISTS `proposition_users` (
  `id_proposition` int(11) NOT NULL AUTO_INCREMENT,
  `id_user_provider` int(11) NOT NULL,
  `id_user_demander` int(11) NOT NULL,
  `is_free` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id_proposition`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE IF NOT EXISTS `request` (
  `id_request` int(11) NOT NULL AUTO_INCREMENT,
  `destination` varchar(50) NOT NULL,
  `arrival` varchar(50) NOT NULL,
  `id_type` int(11) NOT NULL,
  `date` varchar(20) NOT NULL,
  `status` int(11) NOT NULL,
  `is_emergency` int(11) NOT NULL,
  `is_free` int(11) NOT NULL,
  PRIMARY KEY (`id_request`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`id_request`, `destination`, `arrival`, `id_type`, `date`, `status`, `is_emergency`, `is_free`) VALUES
(4, 'msila', 'setif', 2, '2020/04/08', 0, 0, 1),
(5, 'oran', 'alge', 1, '2020/04/08', 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `type_thing`
--

CREATE TABLE IF NOT EXISTS `type_thing` (
  `id_type` int(11) NOT NULL AUTO_INCREMENT,
  `type_thing` varchar(20) NOT NULL,
  PRIMARY KEY (`id_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `type_thing`
--

INSERT INTO `type_thing` (`id_type`, `type_thing`) VALUES
(1, 'Document'),
(2, 'Goods'),
(3, 'Person'),
(4, 'Other');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) CHARACTER SET utf8 NOT NULL,
  `password` varchar(50) CHARACTER SET utf8 NOT NULL,
  `firstname` varchar(20) CHARACTER SET utf8 NOT NULL,
  `lastname` varchar(20) CHARACTER SET utf8 NOT NULL,
  `birthdate` varchar(15) CHARACTER SET utf8 NOT NULL,
  `adress` varchar(30) CHARACTER SET utf8 NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8 NOT NULL,
  `status` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `firstname`, `lastname`, `birthdate`, `adress`, `phone`, `status`, `email`, `type`) VALUES
(1, 'ammar', '11', 'ammar', 'abli', '1995/04/03', 'oulad ddradj', '0665612970', 1, 'ammar@gmail.com', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
